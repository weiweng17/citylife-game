





# 都市浮生 · Godot 版

半开放式都市人生模拟，对标《众生》。**引擎 Godot 4.5 + 像素风 + 目标平台抖音小游戏。**

> 项目骨架已搭好，等你本地装好 Godot 就能直接打开运行。

---

## 为什么换成 Godot

| 项  | 决定                    | 原因                                      |
| -- | --------------------- | --------------------------------------- |
| 引擎 | **Godot 4.5**（MIT 开源） | 像素渲染、光照、动画、场景编辑器远超手写 Canvas             |
| 平台 | **抖音小游戏**             | 抖音 2025 年 12 月**官方适配 Godot 4.5**，完整接入方案 |
| 美术 | **像素风**               | 画质质变的关键——用像素 sprite 替换几何色块              |

**为什么不是微信小游戏**：微信无官方 Godot 支持，社区方案 `godot-love-wechat` 要自编译 WASM、改开发者工具配置、踩 4MB 包体限制，坑多。抖音是官方支持，路顺得多。

---

## 环境准备

Godot 4.5 已下载安装到：

```
C:\Users\86139\.workbuddy\binaries\godot\Godot_v4.5-stable_win64.exe
```

版本验证：`4.5.stable.official.876b29033`

> 注：若终端挂着代理环境变量（`http_proxy`/`https_proxy` = `127.0.0.1:7890`）而代理进程没开，curl 会报 `Connection refused`。
> 此时用 `--noproxy '*'` 直连即可（实测直连 GitHub 可下导出模板，约 1.3 GB）。

### 运行项目

三种方式，挑方便的：

| 方式                | 操作                              | 用途      |
| ----------------- | ------------------------------- | ------- |
| **双击 `run.bat`**  | 直接进游戏，不开编辑器                     | 只想玩/看效果 |
| **双击 `edit.bat`** | 打开 Godot 编辑器，按 F5 运行            | 开发调试    |
| 手动                | Godot → 导入 `project.godot` → F5 | —       |

### 无头验证（不用开界面）

```bash
cd C:/Users/86139/.workbuddy/binaries/godot

# 导入资源
./Godot_v4.5-stable_win64_console.exe --headless --path "<项目路径>" --import

# 跑逻辑验证（地图/移动/交互）
./Godot_v4.5-stable_win64_console.exe --headless --path "<项目路径>" --script res://tools/verify.gd
```

当前验证结果（全部通过）：

```
[OK] 建筑 = 3    树 = 12    交互点 = 5    地面/道路 Sprite = 3
[OK] 移动 223 帧：(300, 320) → (600, 600)，距目标 0 px
[OK] 交互检测：走到地铁站位置正确识别 near_poi = 地铁站
```

---

### 导出发布

导出模板已安装到 `C:\Users\86139\AppData\Roaming\Godot\export_templates\4.5.stable\`（含 Windows + Web）。

```bash
cd C:/Users/86139/.workbuddy/binaries/godot

# Windows 桌面版（已验证可运行）
./Godot_v4.5-stable_win64_console.exe --headless --path "<项目路径>" \
  --export-release "Windows Desktop" "<项目路径>/build/citylife.exe"
```

产物：`build/citylife.exe`（96MB）+ `build/citylife.pck`，**双击 exe 即可游玩**。

### Web 导出（已上线，可分享试玩）

用 **非线程模板**（`web_nothreads_release.zip`，已替换默认的 `web_release.zip`）导出，
避免 SharedArrayBuffer / COOP-COEP 跨域隔离要求——任意静态托管都能直接跑，无需特殊响应头。

```bash
cd C:/Users/86139/.workbuddy/binaries/godot
./Godot_v4.5-stable_win64_console.exe --headless --path "<项目路径>" \
  --export-release "Web" "<项目路径>/build/web/index.html"
```

产物：`build/web/`（index.html + index.js + index.wasm 38MB + index.pck + 图标）。

**试玩链接（已部署到 CloudStudio，手机/电脑浏览器直接打开）：**

```
https://f66037a8457b46eabfde6d79a35fcdde.app.workbuddy.link
```

分享二维码：`build/share_qr.png`（扫一扫即可发给朋友试玩）。

> 注：导出模板曾卡在 96% 加载（线程版需要 COOP/COEP 头）。换非线程模板后已解决，
> `index.js` 里 `SharedArrayBuffer` 仅出现在 `supportsThreads` 特性检测分支，非硬性依赖。

### 中文字体（重要，否则 Web 端全是「豆腐块」）

Godot 默认字体不含中日韩字形。桌面端会回退到系统字体所以「看起来正常」，
但 **Web 导出包里没有系统字体**，中文会全部显示成豆腐块（□）。

**正确做法**：把中文字体嵌进项目，并用 Godot **真正注册的**设置项指定它：

```ini
; project.godot
[gui]
theme/custom_font="res://assets/fonts/GameCN.ttf"
```

> ⚠️ 坑：`gui/theme/default_font` 看着很像，但 **Godot 4 没有注册这个项**，
> 写在配置文件里会被静默忽略（不报错）→ 中文依旧豆腐块。
> 只有 `gui/theme/custom` / `gui/theme/custom_font` 是有效的。

字体由脚本生成（子集化，只保留需要的字形）：

```bash
python tools/gen_font.py     # 输出 assets/fonts/GameCN.ttf（约 2.3MB / 8000+ 字形）
```

覆盖范围 = 源码里出现的所有字符 ∪ **GB2312 全字表** ∪ 常用标点符号区 ∪ ASCII。
**以后新增中文文案，重跑一次 `gen_font.py` 即可**（否则新字会缺字变方块）。

验证字体是否真正生效（headless，不靠猜）：

```bash
godot --headless --script res://tools/check_font.gd
# 期望：default theme font path = res://assets/fonts/GameCN.ttf
```

布局自检（避免 UI 文字被挤成一列）：

```bash
godot --headless --path . res://tools/VerifyLayout.tscn
# 期望：LAYOUT_OK（卡片满宽、描述文字有真实宽度）
```

美术 / 光照自检（素材尺寸 + 光照三层节点）：

```bash
godot --headless --path . res://tools/VerifyArt.tscn
# 期望：ART_OK（11 个素材尺寸符合约束、Ambient/WarmLight/Vignette 三层齐全）
```

> 尺寸是硬约束：玩家 24×32、tile 32×32、建筑 64×64、树 32×40、POI 24×24。
> `VerifyArt` 会把尺寸不符直接判失败——因为改尺寸会悄悄踩坏碰撞体与布局。

## 美术 v3：黑色电影夜景（noir 烘焙光照管线）

> 2026-09-11 按参考图（雨夜街道 / 暗夜办公室）重做整张地图，把画面压成**近黑 + 高对比 + 细节写实**的黑色电影夜城像素风。

### 与 v2 的本质区别

| 维度 | v2（旧） | v3（现） |
|---|---|---|
| 地图 | grass.png + road.png 平铺拼 | **一张烘焙好的 ground.png**（1080×1080，含地面/路面/建筑投影/AO/光斑） |
| 建筑 | 64×64 小色块 | 独立 `building_*.png`（home/hospital/office/store/old），以「脚」为原点做 y_sort |
| 光照 | 运行时 PointLight2D ×5 加法叠加 | **烘焙进图**（ambient + Σ energy/衰减 + AO + glow + emission），不再加动态光 |
| 角色 | 单帧 | `player_walk.png` 4 帧行走动画（AnimatedSprite2D） |
| 氛围 | — | **滚动雨丝**（rain.png）+ **暗角**（vignette）+ 实体按 lightmap 补光 |

### 为什么「不再用 PointLight2D」

烘焙图里已经含光，再叠动态光会把画面**洗成中灰**——这正是旧版「不像参考图」的根因。
现在唯一的光照作用是给**实体**（玩家/NPC）按脚下 `lightmap.png` 采样做 modulate（站灯下烤暖、暗处沉底），与背景同源。

### 氛围量化指标

用「max 通道 < 40 的像素占比」衡量近黑程度：
- 参考图：近黑 61~63%、亮部 0.1%
- 本项目地面：**近黑 50.7%**（不含黑天空，同属暗调）

调参要点（`tools/artlib.py` + `tools/gen_scene.py`）：AMBIENT 压到 `(0.065,0.080,0.115)`、衰减指数用全量 `lt.falloff`(=2.2)、灯能量 `LIGHT_SCALE=0.33`、删掉广域 spill 灯。

### 生成与地图资产

```bash
python tools/gen_scene.py   # 烘焙整张地图 → assets/scene/ground.png + lightmap.png + _lightmap.npy
                            # 以及 assets/sprites/building_*.png / tree.png / lamp.png / rain.png / vignette.png
```

运行时装配在 `scripts/Game.gd`（建筑/树/灯/POI/NPC 坐标与 gen_scene.py 完全一致）。

## 当前进度

### 已完成

- [x] 项目配置（`project.godot`）：360×640 竖屏、**nearest 过滤**（像素风关键）、gl_compatibility 渲染器
- [x] **美术 v3 黑色电影夜景**（2026-09-11 重做）：烘焙光照管线 + 近黑 50.7% + 滚动雨 + 暗角 + 4 帧行走动画（详见「美术 v3」）
- [x] ~~v2 氛围像素风~~（已被 v3 取代）：`gen_pixel_assets.py` 程序化生成的 11 个 sprite（草地/道路/建筑/树/POI/暖光/暗角）
- [x] ~~v2 氛围光照三层~~（已被 v3 取代）：CanvasModulate + PointLight2D ×5 + Vignette
- [x] `scripts/Player.gd`：4 帧行走动画（AnimatedSprite2D）+ CharacterBody2D move_and_slide
- [x] `scripts/Game.gd`：烘焙地图装配（5 栋建筑、20 棵树、12 路灯、8 地点）、相机跟随、点击输入、lightmap 实体补光、滚动雨、靠近交互检测
- [x] `scenes/Main.tscn`：主场景
- [x] **6 个 NPC + 对话系统**：陈姐、老张、老周、疯道士、小雨、阿哲，头顶有名字牌
  - 每个人按「青年/中年/老年」三档说不同的话（共 54 句）
- [x] **主线框架（明线）**：立足 → 成家 → 立业 → 归途，HUD 常驻显示当前目标
- [x] **暗线（奇幻裂缝）**：开局埋「重复的梦」，6 个 NPC 各藏 1 条线索，可追查也可完全无视
- [x] **65 个事件全部迁移**（`scripts/Events.gd` + `data/events.json`）
  - 走到地点即触发，选项带条件判定（不满足显示「条件不足」并禁用）
  - 地点扩到 **7 个**（新增医院、老楼天台），配合场景别名覆盖事件里的全部 10 个场景
- [x] **年度结算 + 12 种结局**（`scripts/Rules.gd` + `data/rules.json`）
  - 收入（技能/人脉加成）、生活成本、房贷、**消费升级**、晋升、失业再就业、创业结算、健康随年龄衰减
  - 四种结束：健康归零 / 心态归零 / 破产 / 活到 60 岁 → 判定 12 种结局之一
  - 结局页显示：结局名 + 描述 + 活了多少岁 + 最后存款 + 线索收集进度，可「再活一次」
- [x] **Web 导出 + 公网试玩**（非线程模板，已部署 CloudStudio，链接见上文「试玩链接」）

### 事件数据从哪来

由 `tools/export_events.mjs` 从 Canvas 版 `citylife/src/data.js` 导出：

```bash
node tools/export_events.mjs
```

它会把 JS 的 `cond` 函数转成可判定的数据（`money_min` / `health_max` / `flags` / `job` …）。  
解析不了的复杂条件记为 `null`——**宽松处理，宁可多触发也别触发不了**（Canvas 版踩过「条件太严导致后期无事件」的坑）。

### 开发路线图（分阶段，一点点做）

**Phase 1 — 开局与可重玩**
- [x] **1.1 出身选择**：四选一（小镇做题家/本地土著/海归硕士/半路转行），不同初始属性 + 开局 flag + 专属开场白；`Data.gd::ORIGINS` + `Game.gd::_build_start_ui/_choose_origin`；结局页「再活一次」回到出身选择
- [x] **1.2 出身驱动事件分支**：`Events.gd::cond_ok` 新增 `origins` 出身限定字段；`events.json` 新增 4 个出身专属早期事件（小镇做题家·考研/本地土著·家里安排/海归·落差/转行·老关系），仅对对应出身触发；顺带补齐 `rules.json` 缺失的 `shop`/`office` 两个职业（此前旧事件引用但无定义，会静默失业）

**Phase 2 — 暗线剧情落地（奇幻灵魂）**
- [x] **2.1 碎片集齐后的「追查」链**：集齐 6 条线索后，地图新增「旧巷口」地点（`POI_DATA` + `scene=alley`）；`_enter_place` 暗线触发优先于普通事件；`Data.DARK_ALLEY` 中段揭示，二选一「继续追 / 放下」
- [x] **2.2 中年抉择**：追查后 40 岁站「老楼天台」触发 `Data.DARK_ROOFTOP` 三分支 → `dark_path_lucid / dark_path_mad / dark_path_awakened` flag
- [x] **2.3 三种暗线专属结局**：`rules.json` 顶部新增 `end_dark_lucid / end_dark_mad / end_dark_awakened`（带完整文案），`judge_ending` 命中 flag 即优先返回；HUD 实时显示暗线状态（碎片 x/6 · 追查中/清醒/疯狂/觉醒/已放下）
- [ ] 2.4 疯道士 / 老周夜晚限定对话（依赖 Phase 3 昼夜）

**Phase 3 — 昼夜与氛围（服务暗线）**
- [x] 3.0 **氛围光照底层就位**：`CanvasModulate` + `PointLight2D` ×5（加法混合）+ 暗角，配套 `gen_pixel_assets.py` 生成 `light_warm.png` / `vignette.png`；`VerifyArt.tscn` 守护
- [ ] 3.1 昼夜循环（时间系统驱动 `CanvasModulate` 颜色 + 暖光 energy 的日夜变化）
- [ ] 3.2 夜晚限定 NPC 与夜间专属事件
- [ ] 3.3 实体化「旧巷口」可进入地点

**Phase 4 — 奇遇系统（小概率高影响）**
- [ ] 4.1 奇遇触发机制（随暗线进度提升概率）
- [ ] 4.2 修仙 / 克苏鲁奇遇事件

**Phase 5 — 结算与结局增强**
- [ ] 5.1 图鉴 / 线索回顾界面
- [ ] 5.2 结合出身 + 暗线的更多结局
- [ ] 5.3 平衡性复核

**Phase 6 — 变现与发布**
- [ ] 6.1 抖音小游戏适配 + 广告接入
- [ ] 6.2 导出抖音包

---

## 目录结构

```
citylife-godot/
├── project.godot              # 项目配置
├── scenes/
│   └── Main.tscn              # 主场景（玩家 + 相机 + UI）
├── scripts/
│   ├── Player.gd              # 角色移动
│   ├── Data.gd                # 数据层：NPC 对话 / 主线阶段 / 暗线（加内容改这里）
│   └── Game.gd                # 地图搭建 + NPC + 对话系统 + 主线推进
├── assets/
│   ├── sprites/               # 像素素材（11 个：9 个造型 + light_warm + vignette）
│   ├── preview_sprites.png    # 素材总览预览（3x）
│   └── preview_scene.png      # 地图合成预览（360x640，含光照/暗角）
└── tools/
    ├── gen_pixel_assets.py    # 素材生成（改配色/造型改这里）
    ├── verify_art.gd          # 美术/光照自检 → ART_OK
    ├── gen_font.py            # 中文字体子集化
    └── verify_font.py         # 字体覆盖自检 → FONT_CHECK_OK
```

---

## 关于素材

> ⚠️ 本节描述的是 **v2** 素材管线，已由 **v3 烘焙管线**取代（见上文「美术 v3」）。以下仅作历史参考。

素材全部由 `tools/gen_pixel_assets.py` **程序化生成**，保证风格统一、可批量迭代。

### 配色从哪来（v2 氛围像素风）

v2 的调色板不是"我觉得"，而是**从一张参考图里逐像素统计出来的**：

| 色系 | 取自参考图的实测值 | 用途 |
|---|---|---|
| 冷调蓝阶 | `#1e2334` → `#7997b3` | 夜景主导色、阴影、冷墙面 |
| 中性月光 | `#464252` → `#d5d6cc` | 水泥、路面、高光 |
| 暖光琥珀 | `#765438` → `#ecd0ac` | 窗口灯光、路灯（**低饱和**，只做稀疏点缀） |

关键结论：参考图的暖色其实**很"灰"**（实测 `#cca789`），画面靠"低饱和 + 低对比 + 冷调统一"出氛围，
而不是靠高饱和撞色。所以规则是——**暖色只出现在光源处，其余一律压进冷调**。

### 三条实现原则

1. **多阶调 + 抖色**：每个材质至少 4 阶（高光/亮/基/暗/深暗），用 4×4 Bayer 有序抖动做两色过渡，去掉"纯色块"感
2. **描边用深藏蓝** `#161824`，不用纯黑（纯黑会把像素画"割裂"）
3. **小尺寸做减法**：10px 宽的脸只保留"左受光 + 右暗柱"，眼睛单独占一行且上方留 1~2 行额头。
   在 24×32 这个尺寸下，加高光块和抖色只会把脸糊成"花斑/墨镜"

### 光照氛围（游戏内，三层）

`Game.gd::_setup_lighting()`：

| 层 | 实现 | 作用 |
|---|---|---|
| 冷调统一 | `CanvasModulate` `(0.90,0.94,1.0)` | 轻微压冷（**不能重**，重了会把素材本身画的颜色再压掉一层） |
| 暖光池 | `PointLight2D` × 5，`BLEND_MODE_ADD` | 建筑窗口/橱窗的暖光，就是参考图里那几团亮 |
| 暗角 | `CanvasLayer(layer=0)` + `vignette.png` | 压住四角、把视线收到中心 |

UI 的 `CanvasLayer` 设为 `layer = 2`，保证永远盖在暗角之上。

### 重新生成

```bash
python tools/gen_pixel_assets.py
# 同时输出 assets/preview_sprites.png（素材总览）和 assets/preview_scene.png（地图合成预览）
```

**改完务必跑一次** `VerifyArt.tscn`——尺寸/光照节点出问题会立刻报错，不用靠肉眼猜。

---

## 原 Canvas 版

`../citylife/` 是之前的纯 Canvas 实现（可运行、已部署试玩）。它的**内容设计要迁移过来**：

- 65 个事件文案与数值
- 五维属性 / 职业 / 年度结算 / 结局判定
- 平衡性模拟脚本（`tools/smoke.js`）的方法论

引擎代码（渲染/移动/UI）在 Godot 里重写，但**内容和数值不依赖引擎，可以直接搬**。
